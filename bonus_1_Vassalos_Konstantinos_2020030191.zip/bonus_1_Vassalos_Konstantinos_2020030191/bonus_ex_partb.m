clc;
clear all;
close all;
clear;
%%
n=2;
A = randn(n, n);
[U, S, V] = svd(A);
lmin=10;
lmax=1000;

z=lmin+(lmax-lmin)*rand(n-2,1);

eig_P = [lmin;lmax; z];

lamda= diag(eig_P);

K=lmax/lmin;
q=randn(n,1);
P=U*lamda*U';

%
x_optimal = -inv(P)*q;


%%
 a = -1*ones(n,1); b = 3*ones(n,1);
cvx_begin
variables x(n)
minimize(1/2.*x'*P*x + q'*x)
subject to 
-x+a <= 10e-6;
x-b<=10e-6
cvx_end

optimal_value_of_f=cvx_optval;
%%
% gradient algorithm

k=0;
xk=randn(n,1);
epsilon=10e-8;
f=@(x) 1/2*(x')*P*x+(q')*x;
all_xk=zeros(2,k);
fun_val=zeros(1,k);
grad=P*xk+q;
t=1/max(eig(P));
while (norm(projection_b(xk-t*grad)-xk)/norm(projection_b(xk-t*grad))>epsilon)
    
    xk=projection_b(xk-t * grad); 
    grad=P*xk+q;
    
        k=k+1;
    fun_val(k)=f(xk);
    all_xk(:,k)=xk;
     fprintf("\nIteration : %d, value of f %f",k,fun_val(k));
end
fprintf("\n Optimal point for  Gradient algorithm is %f",fun_val(k));
%%
%accelerated gradient algorithm
k1=0;
xk1=randn(n,1);
yk1=xk1;
epsilon=10e-8;
f=@(x) 1/2*(x')*P*x+(q')*x;
all_xk1=zeros(2,k1);
fun_val1=zeros(1,k1);
gradxk1=P*xk1+q;
gradyk1=P*yk1+q;
t=1/lmax;
beta=(sqrt(lmax)-sqrt(lmin))/(sqrt(lmax)+sqrt(lmin));
while(norm(projection_b(yk1-t*gradyk1)-xk1)/norm(projection_b(yk1-t*gradyk1))>epsilon)
     k1=k1+1; 
     all_xk1(:,k1)=xk1;
    fun_val1(k1)=f(xk1);
    x_temp=xk1;
    xk1=projection_b(yk1-t*gradyk1);
    yk1=xk1+beta*(xk1-x_temp);
   
    gradxk1=P*xk1+q;
    gradyk1=P*yk1+q;
end
fprintf("\n Optimal point for accelerated Gradient algorithm is %f",fun_val1(k1));
%%
k_axis = 1:k;
k1_axis= 1:k1;

x1 = -2:0.01:2;
x2 = -2:0.01:2;
[X1, X2] = meshgrid(x1, x2);
Z = 1/2 * (P(1, 1) * X1.^2 + P(2, 2) * X2.^2 + 2 * P(1, 2) * X1 .* X2) + q(1) * X1 + q(2) * X2;

figure;
contour(X1, X2, Z,fun_val);
hold on;
plot(all_xk(1,:),all_xk(2,:),'*-');
xlabel('x1');
ylabel('x2');
title('Contour Plot with Trajectories for Gradient algorithm');
legend('Contour Plot', 'Gradient algorithm');
hold off;

figure;
contour(X1, X2, Z,fun_val1);
hold on;
plot(all_xk1(1,:),all_xk1(2,:),'*-');
xlabel('x1');
ylabel('x2');
title('Contour Plot with Trajectories for accelerated Gradient algorithm');
legend('Contour Plot', ' accelerated Gradient algorithm');
hold off;

% Calculate log differences
quant_grad = fun_val(1:k) - optimal_value_of_f;
quant_acc_grad =fun_val1(1:k1) - optimal_value_of_f;
figure;
semilogy(k_axis, quant_grad, 'b');

xlabel('Iteration (k)');
ylabel('log(f(x_k) - p^*)');
title('Gradient algorithm');
legend('Gradient algorithm');

figure;
semilogy(k1_axis, quant_acc_grad, 'r');
xlabel('Iteration (k1)');
ylabel('log(f(x_k1) - p^*)');
title('Accelerated Gradient algorithm');
legend('Accelerated Gradient algorithm');

%%
figure ;
semilogy(k_axis,quant_grad,'r-','LineWidth',2);
hold on
semilogy(k1_axis,quant_acc_grad,'b-','LineWidth',2);
xlabel('Iteration (k1)');
ylabel('log(f(x_k) - p^*)');
title('Convergence Plot');
legend(' Gradient algorithm','Accelerated Gradient algorithm');

%%
%projection func
function y = projection_b(x)
n=2;
    a = -1*ones(n,1); b = 3*ones(n,1);
     y = x;

    if(x > a)
        y = min(x, b);
    end

    if(x < b)
        y = max(x, a);
    end

end

