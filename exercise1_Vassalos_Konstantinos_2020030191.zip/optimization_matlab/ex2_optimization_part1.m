%1
[x1,x2]=meshgrid(0:.2:3);
R=1+x1+x2;
F=1./R;

figure (1);
mesh(x1,x2,F);
hold on;
title('f(x)');
xlabel('x1');
ylabel('x2');

contour_levels=linspace(0.1,0.8,9);
figure(4);
contour(x1,x2,F,contour_levels);
xlabel('x');
ylabel('y');
grid on;
syms x1 x2;

f = 1 / (1 + x1 + x2);

x01=3;
x02=1;
step = 0.2;
x1_grid = 0:step:3;
x2_grid = 0:step:3;

        grad_f = gradient(f, [x1, x2]);
        grad_f = subs(grad_f, {x1, x2}, {x01, x02});
       
        hessian_f = hessian(f, [x1, x2]);
        hessian_f = subs(hessian_f, {x1, x2}, {x01, x02});
        f_x0=1/(1+x01+x02);
        f_approx = f_x0 + grad_f(1) * (x1 - x01) + grad_f(2) * (x2 - x02);
        
        f_second_approx = f_approx + 0.5 * [(x1 - x01), (x2 - x02)] * hessian_f * [(x1 - x01); (x2 - x02)];

        for k = 1:length(x2_grid)
            for l = 1:length(x1_grid)
                x1_val = x1_grid(l);
                x2_val = x2_grid(k);
                    f_values(k, l) = subs(f, {x1, x2}, {x1_val, x2_val});
                    f_approx_values(k, l) = subs(f_approx, {x1, x2}, {x1_val, x2_val});
                    f_second_approx_values(k, l) = subs(f_second_approx, {x1, x2}, {x1_val, x2_val});
          
            end
        end
        figure(2)
      
        mesh(x1_grid, x2_grid, f_values(:, :), 'FaceAlpha', 0.5, 'EdgeColor', 'b');
        hold on;
        mesh(x1_grid, x2_grid, f_approx_values(:, :), 'FaceAlpha', 0.5, 'EdgeColor', 'r');
        xlabel('x1');
        ylabel('x2');
     
        figure(3)
       
         mesh(x1_grid, x2_grid, f_values(:, :), 'FaceAlpha', 0.5, 'EdgeColor', 'b');
        hold on;
        
        mesh(x1_grid, x2_grid, f_second_approx_values(:, :), 'FaceAlpha', 0.5, 'EdgeColor', 'g');
        title(['(x01=4' ,' x02=2)']);
        xlabel('x1');
        ylabel('x2');













