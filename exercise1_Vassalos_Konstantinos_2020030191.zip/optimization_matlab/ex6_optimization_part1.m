
A = randn(2, 2);
P = A * A';
q = [1; 2];
r = 3;

[x1, x2] = meshgrid(-5:0.1:5, -5:0.1:5); 
f= 0.5 * (x1.^2 * P(1, 1) + x2.^2 * P(2, 2) ...
    + (x1 .* x2) * (P(1, 2) + P(2, 1))) + q(1) * x1 + q(2) * x2 + r;
P
q
x_optimal = -q\P

figure;
mesh(x1, x2, f);
xlabel('x1');
ylabel('x2');
zlabel('f(x)');
title('Mesh Plot of f(x)');

figure;
contour(x1, x2, f, 20);

hold on;
plot(x_optimal(1), x_optimal(2), 'ro', 'MarkerSize', 10, 'LineWidth', 2);
xlabel('x1');
ylabel('x2');
title('Contour Plot of f(x)');
legend('Optimal Point x*');
