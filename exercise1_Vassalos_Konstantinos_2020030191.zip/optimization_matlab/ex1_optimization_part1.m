
x = linspace(0,3,100);
x0_values = [ 0, 1, 2];
f = @(x) 1./(1 + x);
f1_x = zeros(length(x0_values), length(x));
f2_x = zeros(length(x0_values), length(x));

for i = 1:length(x0_values)
    x0 = x0_values(i);
    f_prime_x0 = -1 / (1 + x0)^2;
    f_double_prime_x0 = 2 / (1 + x0)^3;
    
    f1_x(i, :) = f(x0) + f_prime_x0 * (x - x0);
    f2_x(i, :) = f(x0) + f_prime_x0 * (x - x0) + (1/2) * f_double_prime_x0 * (x - x0).^2;
end

figure;
plot(x, f(x),'LineWidth',2,'DisplayName',sprintf("f(x)"));
hold on;

for i = 1:length(x0_values)
    plot(x, f1_x(i, :), '--', 'DisplayName', sprintf("f(1)(x) at x0=%d", x0_values(i)));
    plot(x, f2_x(i, :), '-.', 'DisplayName', sprintf("f(2)(x) at x0=%d", x0_values(i)));
end

legend('Location', 'Best');
title('f(x), f(1)(x), and f(2)(x) for Various x0');
xlabel('x');
ylabel('y');
grid on;