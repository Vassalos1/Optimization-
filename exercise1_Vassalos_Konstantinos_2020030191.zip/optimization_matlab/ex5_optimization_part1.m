[x1, x2] = meshgrid(-3:0.1:3, -3:0.1:3);
f1=sqrt(x1.^2+x2.^2);
f2 = x1.^2 + x2.^2;

figure(1);
mesh(x1, x2, f1);
title('f1(x) = ||x||_2');


figure(2);
mesh(x1, x2, f2);

title('f2(x) = ||x||_2^2');


xlabel('x1');
ylabel('x2');
axis equal;


x = linspace(0.1, 2, 10);  
a_values_i = [1, 0.5, 0.25, 0];
a_values_ii = [-1, -0.5, 2, 3];


figure(3);
hold on;

for a = a_values_i
    y = x.^a;
    plot(x, y, 'DisplayName', ['a = ', num2str(a)]);
end

title('f(x) = x^a for a >= 1 and a <= 0');
xlabel('x');
ylabel('f(x)');
legend('Location', 'Northwest');
grid on;


figure(4);
hold on;

for a = a_values_ii
    y = x.^a;
    plot(x, y, 'DisplayName', ['a = ', num2str(a)]);
end

title('f(x) = x^a for 0 <= a <= 1');
xlabel('x');
ylabel('f(x)');
legend('Location', 'Northwest');
grid on;



